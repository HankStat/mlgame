"""
The template of the main script of the machine learning process
"""
import os
import pickle

import numpy as np

# python MLGame.py -i model_DJ.py arkanoid NORMAL 2
class MLPlay:
    def __init__(self):
        """
        Constructor
        """
        self.ball_served = False
        self.prev_ball = (93,395)
        # Need scikit-learn==0.22.2 
        # with open(os.path.join(os.path.dirname(__file__), 'save', 'model.pickle'), 'rb') as f:
        #     self.model = pickle.load(f)
        with open(os.path.join(os.path.dirname(__file__), 'my_model.pickle'), 'rb') as f:
            self.model = pickle.load(f)

    def update(self, scene_info):
        """
        Generate the command according to the received `scene_info`.
        """
        # Make the caller to invoke `reset()` for the next round.
        if (scene_info["status"] == "GAME_OVER" or
                scene_info["status"] == "GAME_PASS"):
            return "RESET"

        if not self.ball_served:
            self.ball_served = True
            command = "SERVE_TO_LEFT"
        else:
            x_ball = scene_info["ball"][0]
            y_ball = scene_info["ball"][1]
            x_speed = x_ball-self.prev_ball[0]
            y_speed = y_ball-self.prev_ball[1]
            plat = scene_info["platform"][0]
            # print(x_speed)
            # print(y_speed)
            dest = 100
            if y_speed != 0:
                slope=x_speed/y_speed
            if y_ball > 320 and y_speed <0:
                dest = x_ball
            elif y_speed > 0 and y_ball > 270 :
                dest=x_ball+(395-y_ball)*slope
                if dest >= 390:
                    dest=dest-390
                elif dest >=195:
                    dest=390-dest
                elif dest <=0 and dest >=-195:
                    dest=dest*(-1)
                elif dest < -195:
                    dest =dest +390
            x = np.array([x_ball, y_ball, x_speed, y_speed, plat]).reshape((1, -1))
            y = self.model.predict(x)

            if y == 0:
                command = "NONE"
            elif y == -1:
                command = "MOVE_LEFT"
            elif y == 1:
                command = "MOVE_RIGHT"

            self.prev_ball = scene_info["ball"]
        return command

    def reset(self):
        """
        Reset the status
        """
        self.ball_served = False
        self.prev_ball = (93,395)
        
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 24 12:27:25 2021

@author: User
"""

import os
import pickle
import numpy as np
class MLPlay:
    def __init__(self):
        """
        Constructor

        @param side A string "1P" or "2P" indicates that the `MLPlay` is used by
               which side.
        """
        self.head_x = 40
        self.head_y = 40
        with open(os.path.join(os.path.dirname(__file__), 'my_model.pickle'), 'rb') as f:
            self.model = pickle.load(f)



    def update(self, scene_info):
        """
        Generate the command according to the received scene information
        """
        """
        
        如果是兩個 model 可以在程式中用 side 去判斷要用哪個 model 
        

        """
        if scene_info["status"] == "GAME_OVER":
            return "RESET"

        body = []
        head_x = scene_info["snake_head"][0]
        head_y = scene_info["snake_head"][1]
        food_x = scene_info["food"][0]
        food_y = scene_info["food"][1]
        x_speed = head_x - self.head_x
        y_speed = head_y - self.head_y
        cannotright = 0
        cannotleft = 0
        cannotup = 0
        cannotdown = 0
        previous = 1
        # check = 0
        # for obj in scene_info["snake_body"]:
        #     if head_x != obj[0] and head_y != obj[1]:
        #         break
        #     check+=1
        # if check >= len(scene_info["snake_body"]):
        #     check = 0
        for obj in scene_info["snake_body"]:
            body.append((obj[0],obj[1]))
        self.head_x = head_x
        self.head_y = head_y
        for bo in body:
            if bo[0]==head_x and bo[1] == head_y + 10:
                cannotdown = 1
            if bo[0]==head_x and bo[1] == head_y - 10:
                cannotup = 1
            if bo[0]==head_x +10 and bo[1] == head_y:
                cannotright = 1
            if bo[0]==head_x - 10 and bo[1] == head_y:
                cannotleft = 1
        if y_speed < 0:
            previous = 0
        if y_speed > 0:
            previous = 1
        if x_speed < 0:
            previous = 2
        if x_speed > 0:
            previous = 3
        x = np.array([head_x,head_y,food_x,food_y,cannotleft,cannotright,cannotup,cannotdown, previous]).reshape((1, -1))
        y = self.model.predict(x)

        if y == 0:
            command = "UP"
        elif y == 1:
            command = "DOWN"
        elif y == 2:
            command = "LEFT"
        elif y==3:
            command = "RIGHT"
        return command

    def reset(self):
        """
        Reset the status
        """
        self.head_x = 40
        self.head_y = 40

"""
The template of the script for the machine learning process in game pingpong
"""
"""
ml_play 程式只能交一份，且檔名為 ml_play.py
"""
import os
import pickle
import numpy as np
import random
# ult = []
class MLPlay:
    def __init__(self, side):
        """
        Constructor

        @param side A string "1P" or "2P" indicates that the `MLPlay` is used by
               which side.
        """
        self.ball_served = False
        self.side = side
        self.move_plat = False
        self.count=0
        self.final = random.randint(-15,17)
        self.block = 0
        self.blocker = 0
        if self.side == "1P":
            with open(os.path.join(os.path.dirname(__file__), 'my_model_5500(1).pickle'), 'rb') as f:
                self.model = pickle.load(f)
        elif self.side == "2P":
            with open(os.path.join(os.path.dirname(__file__), 'my_model_5500(2).pickle'), 'rb') as f:
                self.model = pickle.load(f)
        

        """
        load your "1P" and "2P" model here
        可以是一個檔案或是兩個檔案，但相對路徑要放好 (路徑請用相對路徑，並放在相同目錄底下)
        
        sample 1: (如果 "1P", "2P" 是分開 train)
        self.model_1 = 1P pickle
        self.model_2 = 2P pickle
        
        sample 2: (如果 "1P", "2P" train 成一個 model)
        self.model = "1P" and "2P" pickle
        """

    def update(self, scene_info):
        """
        Generate the command according to the received scene information
        """
        """
        
        如果是兩個 model 可以在程式中用 side 去判斷要用哪個 model 
        
        sample 1: (如果 "1P", "2P" 是分開 train)
        if self.side == "1P":
            # 使用 model 1 預測
        else:
            # 使用 model 2 預測
            
        sample 2: (如果 "1P", "2P" train 成一個 model)
        # 直接使用 model 預測
        """
        if scene_info["status"] != "GAME_ALIVE":
            print(scene_info["ball_speed"])
            return "RESET"

        if not self.ball_served:
            if scene_info["ball"][1] == 415:
                if self.side == "2P":
                    self.ball_served = True
                    command = "NONE"
                elif self.side == "1P":
                    if not self.move_plat:
                        if self.count< abs(self.final):
                            if self.final < 0:
                                command = "MOVE_LEFT"
                            else:
                                command = "MOVE_RIGHT"
                            self.count+=1
                        else:
                            self.move_plat=True
                    if self.move_plat:
                        self.ball_served = True
                        k= random.randint(0, 1)
                        if k==0:
                            command = "SERVE_TO_LEFT"
                        else:
                            command = "SERVE_TO_RIGHT"
            elif scene_info["ball"][1] == 80:
                if self.side == "1P":
                    self.ball_served = True
                    command = "NONE"
                elif self.side == "2P":
                    if not self.move_plat:
                        if self.count< abs(self.final):
                            if self.final < 0:
                                command = "MOVE_LEFT"
                            else:
                                command = "MOVE_RIGHT"
                            self.count+=1
                        else:
                            self.move_plat=True
                    if self.move_plat:
                        self.ball_served = True
                        k= random.randint(0, 1)
                        if k==0:
                            command = "SERVE_TO_LEFT"
                        else:
                            command = "SERVE_TO_RIGHT"
        else:
            x_ball = scene_info["ball"][0]
            y_ball = scene_info["ball"][1]
            x_speed = scene_info["ball_speed"][0]
            y_speed = scene_info["ball_speed"][1]
            if self.side == "1P":
                plat = scene_info["platform_1P"][0]
            elif self.side == "2P":
                plat = scene_info["platform_2P"][0]
            blocker = scene_info["blocker"][0]
            block_speed = blocker-self.blocker
            if y_speed != 0:
                slope=x_speed/y_speed
            else:
                slope = 0
            x = np.array([x_ball, y_ball,x_speed, y_speed,slope,block_speed, blocker, plat]).reshape((1, -1))
            y = self.model.predict(x)

            if y == 0:
                command = "NONE"
            elif y == -1:
                command = "MOVE_LEFT"
            elif y == 1:
                command = "MOVE_RIGHT"
            self.blocker = scene_info["blocker"][0]
        return command

    def reset(self):
        """
        Reset the status
        """
        self.ball_served = False
        self.move_plat = False
        self.count=0
        self.block = 0
        self.final = random.randint(-15,17)
        self.blocker = 0
    # def record(self, scene_info):
    #      if scene_info["status"] != "GAME_ALIVE":
    #         global ult
    #         ult = [abs(scene_info["ball_speed"][1])]
